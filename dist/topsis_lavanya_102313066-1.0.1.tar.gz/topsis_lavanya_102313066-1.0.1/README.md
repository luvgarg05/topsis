# TOPSIS-Lavanya-102313066

[![PyPI version](https://badge.fury.io/py/Topsis-Lavanya-102313066.svg)](https://badge.fury.io/py/Topsis-Lavanya-102313066)
![Python 3.7+](https://img.shields.io/badge/Python-3.7%2B-blue)
![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)

A Python package and Web Service for the Technique for Order of Preference by Similarity to Ideal Solution (TOPSIS).

## 📋 Table of Contents

- [About TOPSIS](#-about-topsis)
- [System Flowchart](#-system-flowchart)
- [Installation](#-installation)
- [Usage (CLI & Python)](#-usage)
- [Web Application](#-web-application)
- [Mathematics Behind TOPSIS](#-mathematics-behind-topsis)
- [Project Structure](#-project-structure)
- [License](#-license)
- [Author](#-author)

## 🧠 About TOPSIS

TOPSIS is a multi-criteria decision analysis method. It is based on the concept that the chosen alternative should have the shortest geometric distance from the positive ideal solution (PIS) and the longest geometric distance from the negative ideal solution (NIS).

This project provides a complete suite to perform TOPSIS analysis:

- **Command Line Tool**: For quick, local analysis
- **Python Package**: Installable via PyPI, usable in your Python scripts
- **Web Service**: Cloud-based interface with drag-and-drop, email integration, and real-time results

**PyPI Link**: https://pypi.org/project/Topsis-Lavanya-102313066/

## 🔄 System Flowchart

```
User Input (Data, Weights, Impacts)
           ↓
    File Upload (CSV/Excel/JSON)
           ↓
    Data Normalization
           ↓
    Apply Weights
           ↓
    Find Ideal Solutions
           ↓
    Calculate Separations
           ↓
    Calculate Scores & Ranks
           ↓
    Display Results + Email
```

## 📦 Installation

Install the package directly from PyPI:

```bash
pip install Topsis-Lavanya-102313066
```

## 💻 Usage

### 1. Command Line Interface (CLI)

Calculate TOPSIS scores directly from your terminal.

**Syntax:**
```bash
topsis-cli <InputDataFile> <Weights> <Impacts> <ResultFileName>
```

**Example:**
```bash
topsis-cli data.csv "1,1,1,2" "+,+,+,-" result.csv
```

**Inputs:**
- `InputDataFile`: CSV file containing the data matrix
- `Weights`: Comma-separated weights (e.g., 1,1,1,2)
- `Impacts`: Comma-separated impacts (+ for beneficial, - for non-beneficial)
- `ResultFileName`: Path to save the output file

**Output:**
```
Alternative,Storage,RAM,Price,Battery,Topsis Score,Rank
M5,512,16,50000,7000,0.8954,1
M2,512,12,40000,6000,0.7823,2
M1,256,8,30000,5000,0.5621,3
```

### 2. Python Library

Import the package in your Python scripts.

```python
from topsis_lavanya_102313066 import topsis

# topsis(input_file, weights, impacts, output_file)
result = topsis("data.csv", "1,1,1,2", "+,+,+,-", "output.csv")
print(result)
```

**Parameters:**
- `input_file` (str): Path to CSV file with first column as identifiers
- `weights` (str or list): Comma-separated weights or list
- `impacts` (str or list): Comma-separated impacts (+ or -) or list
- `output_file` (str, optional): Output file path

**Returns:**
- `pd.DataFrame`: Results with Topsis Score and Rank columns

## 🌐 Web Application

A live web service provides a graphical user interface for TOPSIS analysis.

**Features:**
- ✅ Drag & Drop Interface: Upload .csv, .xlsx, .xls, or .json files
- ✅ Multi-Format Support: Automatic format detection
- ✅ Real-Time Validation: Instant feedback on inputs
- ✅ Email Integration: Results delivered to your inbox
- ✅ CSV Download: Download results instantly
- ✅ Professional UI: Modern dark theme with cyan accents

**Local Access:**
```bash
cd web_service
pip install -r requirements.txt
python app.py
```

Then visit: http://localhost:5000

## 🧮 Mathematics Behind TOPSIS

The TOPSIS process involves the following steps:

### Step 1: Normalize the Decision Matrix
$$r_{ij} = \frac{x_{ij}}{\sqrt{\sum_{i=1}^{m} x_{ij}^2}}$$

### Step 2: Calculate Weighted Normalized Decision Matrix
$$v_{ij} = w_j \times r_{ij}$$

### Step 3: Determine Ideal Solutions
- **Ideal Best (V+):** $v_j^+ = \max(v_{ij})$ if impact is (+), $\min(v_{ij})$ if (-)
- **Ideal Worst (V-):** $v_j^- = \min(v_{ij})$ if impact is (+), $\max(v_{ij})$ if (-)

### Step 4: Calculate Separation Measures
$$S_i^+ = \sqrt{\sum_{j=1}^{n} (v_{ij} - v_j^+)^2}$$
$$S_i^- = \sqrt{\sum_{j=1}^{n} (v_{ij} - v_j^-)^2}$$

### Step 5: Calculate Performance Score
$$P_i = \frac{S_i^-}{S_i^+ + S_i^-}$$

Score range: 0 to 1 (higher is better)

### Step 6: Rank Alternatives
Sort by performance score in descending order (highest score = Rank 1)

## 📂 Project Structure

```
Topsis-Lavanya-102313066/
├── topsis_package/              # PyPI Package Source
│   ├── topsis_lavanya_102313066/
│   │   ├── __init__.py
│   │   ├── topsis.py            # Core algorithm
│   │   └── cli.py               # Command-line interface
│   ├── setup.py                 # Package configuration
│   ├── README.md                # Package documentation
│   ├── LICENSE                  # MIT License
│   └── MANIFEST.in
│
├── web_service/                 # Web Service
│   ├── app.py                   # Flask Application
│   ├── requirements.txt          # Dependencies
│   ├── templates/               # HTML Templates
│   │   └── index.html           # Web UI
│   ├── uploads/                 # Temporary file storage
│   ├── .env                     # Configuration
│   ├── .env.example             # Configuration template
│   └── README.md                # Web service documentation
│
├── topsis.py                    # Standalone CLI program
├── data.csv                     # Sample dataset
├── test_all.py                  # Test suite
├── README.md                    # Main documentation
├── COMPLETE_GUIDE.md            # Comprehensive guide
├── DEPLOYMENT_GUIDE.md          # Deployment instructions
├── QUICK_REFERENCE.md           # Quick commands
└── LICENSE                      # MIT License
```

## 📊 Example Use Case

### Mobile Phone Selection

**Data (data.csv):**
```csv
Mobile,Storage,RAM,Price,Battery
M1,256,8,30000,5000
M2,512,12,40000,6000
M3,128,4,15000,3000
M4,256,6,25000,4500
M5,512,16,50000,7000
```

**Analysis:**
```bash
topsis-cli data.csv "1,1,1,2" "+,+,-,+" result.csv
```

**Results (result.csv):**
```
Mobile,Storage,RAM,Price,Battery,Topsis Score,Rank
M5,512,16,50000,7000,0.8954,1
M2,512,12,40000,6000,0.7823,2
M1,256,8,30000,5000,0.5621,3
M4,256,6,25000,4500,0.3847,4
M3,128,4,15000,3000,0.1892,5
```

**Interpretation:** M5 is the best phone based on the criteria with weight emphasis on battery life.

## ✨ Features

- ✅ Complete TOPSIS algorithm implementation
- ✅ Command-line interface
- ✅ Python library for integration
- ✅ Web-based user interface
- ✅ Multi-file format support (CSV, Excel, JSON)
- ✅ Email result delivery
- ✅ Input validation and error handling
- ✅ Comprehensive documentation
- ✅ Production-ready code

## 🔧 Requirements

- Python 3.7 or higher
- pandas >= 1.0.0
- numpy >= 1.18.0
- Flask >= 2.3.3 (for web service)
- openpyxl >= 3.1.5 (for Excel support)
- python-dotenv >= 1.0.0 (for configuration)

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👨‍💻 Author

**Lavanya Garg**

- Roll Number: 102313066
- Institution: Thapar Institute of Engineering and Technology
- Email: lgarg_be23@thapar.edu
- GitHub: https://github.com/lavanya-garg

## 🙏 Acknowledgments

- TOPSIS methodology based on Hwang & Yoon (1981)
- Inspired by real-world multi-criteria decision-making problems
- Built with Python, Flask, and modern web technologies

## 📞 Support

For issues, questions, or suggestions:
1. Check the [Complete Guide](COMPLETE_GUIDE.md)
2. Review [Quick Reference](QUICK_REFERENCE.md)
3. Check [Troubleshooting](DEPLOYMENT_GUIDE.md#troubleshooting)
4. Open an issue on GitHub

---

**Happy TOPSIS Analysis!** 🚀

